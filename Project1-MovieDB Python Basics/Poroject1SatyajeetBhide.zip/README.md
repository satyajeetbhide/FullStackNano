# FullStackNano
Steps to Launch the application:
1. Open a terminal and navigate to the location where this zip is unpacked.
2. Locate file "mediacenter.py" in the folder.
3. In the terminal, run the cmd "python mediacenter.py" to launch the application.
4. This should launch the webpage in a new browser tab.